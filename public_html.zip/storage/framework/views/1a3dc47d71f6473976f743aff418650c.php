<div class="container">
        <?php
        $__assetKey = '2301013882-0';

        ob_start();
    ?> 
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/profile/index.css']); ?>
        <?php
        $__output = ob_get_clean();

        // If the asset has already been loaded anywhere during this request, skip it...
        if (in_array($__assetKey, \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$alreadyRunAssetKeys)) {
            // Skip it...
        } else {
            \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$alreadyRunAssetKeys[] = $__assetKey;
            \Livewire\store($this)->push('assets', $__output, $__assetKey);
        }
    ?>
    <aside>     
        <nav>
            <ol>
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $professions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profession): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><a wire:click="sortByProfession(<?php echo e($profession->id); ?>)" class="nav_btns"><?php echo e($profession->title); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </ol>
        </nav>
    </aside>

    <div class="cart_container">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="cart">
                <div class="cart-top">
                    <img src="<?php echo e(!$profile->avatar ? asset('/imgs/profile/avatar.jpg') : $profile->avatarUrl); ?>" alt="" class="cart-img">
                    <ul class="cart-list">
                        <li class="cart-item"><?php echo e($profile->user->name); ?></li>
                        <li class="cart-item">Опыт работы : <?php echo e($profile->expirience); ?></li>
                        <li class="cart-item">Навыки : <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $profile->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($skill->title . ' '); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]--></li>
                    </ul>
                </div>
                <div class="cart-bottom">
                    <a target="_blank" href="<?php echo e($profile->portfolio); ?>" class="work-link">Список работ</a>
                    <a href="<?php echo e(auth()->user() ? ('https://wa.me/' . $profile->user->phonenumber) : route('auth.login')); ?>" target="_blank" class="work-whatstapp">
                        <img src="<?php echo e(asset('imgs/profile/index/whatsapp.png')); ?>" alt="">
                        <span>+7777553535</span>
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div><?php /**PATH C:\xampp\htdocs\livewire-hh\resources\views/livewire/profile/index.blade.php ENDPATH**/ ?>