<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('imgs/logo.png')); ?>">
    <title>Energo job</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/welcome.css']); ?>
</head>
<body>
    <header>
        <div class="logo">
            <a href="https://akep-65.kz"><img src="<?php echo e(asset('imgs/logo.png')); ?>" alt="" style="width: 140px;height: 140px;"></a>
        </div>
            <div class="btns">
                <a class="btn" href="<?php echo e(route('auth.login')); ?>">
                    <p>Опубликовать свои услуги</p>
                </a>
                <p class="hdr_text">
                    Фриланс услуги для <br> вашего бизнеса!
                </p>
                <a class="btn" href="<?php echo e(route('auth.login')); ?>">
                    <p>Найти исполнителя</p>
                </a>
            </div>
    </header>

    <?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\livewire-hh\resources\views/layouts/welcome.blade.php ENDPATH**/ ?>