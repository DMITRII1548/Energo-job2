<div>
        <?php
        $__assetKey = '712856404-0';

        ob_start();
    ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/profile/update_or_create.css']); ?>
        <?php
        $__output = ob_get_clean();

        // If the asset has already been loaded anywhere during this request, skip it...
        if (in_array($__assetKey, \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$alreadyRunAssetKeys)) {
            // Skip it...
        } else {
            \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$alreadyRunAssetKeys[] = $__assetKey;
            \Livewire\store($this)->push('assets', $__output, $__assetKey);
        }
    ?>

       <form class="width" wire:submit="updateOrCreate">
        <div class="background">
            <div class="box">
                <div class="profile">
                    <div>
                        <div class="image" style="position: relative;">
                            <!--[if BLOCK]><![endif]--><?php if($form->avatar): ?>
                                <img src="<?php echo e($form->avatar->temporaryUrl()); ?>" style="position: absolute; z-index: 2; left: 0;">
                            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                            <img style="opacity: 0;">
                            <img style="z-index: 1; position: absolute; left: 0;" src="<?php echo e(\App\Models\User::find(auth()->user()->id)->profile
                            && \App\Models\User::find(auth()->user()->id)->profile->avatar
                                ? \App\Models\User::find(auth()->user()->id)->profile->avatarUrl
                                : asset('imgs/profile/avatar.jpg')); ?>" alt="">
                        </div>
                        <input type="file"  wire:model="form.avatar" id="avatar_paste" class="btn1" style="display: none">
                        <label class="btn1" for="avatar_paste">
                            Вставить изображение
                        </label>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.avatar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                    <div class="info">
                        <input wire:model="form.name" type="text" placeholder="ФИО" name="Full-name">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p><?php echo e($message); ?></p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        <input wire:model="form.phonenumber" type="tel" placeholder="Номер" name="Full-name" required>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.phonenumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        <input wire:model="form.expirience" type="text" placeholder="Опыт работы" name="Full-name" required>
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.expirience'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                        <input wire:model="form.portfolio" type="url" placeholder="Ссылка на портфолио ( если есть )" name="Full-name">
                        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.portfolio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p><?php echo e($message); ?></p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                    </div>
                </div>

                <div class="professions">
                    <!-- Add product with livewire dont forget -->
                    <div class="padding">
                        <div class="cards" id="proffesions">
                            <a>Профессии:</a>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $selectedProfessions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profession): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span wire:click="destroyProfession(<?php echo e($profession->id); ?>)" class="card"> <?php echo e($profession->title); ?> <div class="cross"></div> </span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                            <!-- <span class="card">Test <div class="cross"></div> </span> -->
                        </div>

                        <label for="professions" class="btn3 btn-label">Добавить</label>
                        <select id="professions" name="professions[]" class="btn2" wire:model="profession" wire:change="addProfession">
                            <option id="selectDefProf" disabled selected>Добавить</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $professions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profession): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($profession->id); ?>"><?php echo e($profession->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>
                </div>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.professions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                <div class="skills">
                    <!-- Add product with livewire dont forget -->
                    <div class="padding">
                        <div class="cards" id="skillsCards">
                            <a>Навыки:</a>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $selectedSkills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span wire:click="destroySkill(<?php echo e($skill->id); ?>)" class="card"> <?php echo e($skill->title); ?> <div class="cross"></div> </span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </div>

                        <label for="skills" class="btn3 btn-label">Добавить</label>
                        <select class="btn3" id="skills" wire:model="skill" wire:change="addSkill">
                            <option id="defSkillOption" disabled selected>Добавить</option>
                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($skill->id); ?>"><?php echo e($skill->title); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                        </select>
                    </div>
                </div>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.skills'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->

                <!--[if BLOCK]><![endif]--><?php if($isCreatedOrUpdated): ?>
                    <p>Ваш профиль на проверке</p>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                <div class="confirm">
                    <button type="submit" class="btn4">подтвердить</button>
                </div>
            </div>
        </div>
    </form>
    
</div>
<?php /**PATH /home/a0984209/domains/a0984209.xsph.ru/public_html/resources/views/livewire/profile/update-or-create.blade.php ENDPATH**/ ?>