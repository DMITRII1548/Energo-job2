<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\livewire-hh\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>