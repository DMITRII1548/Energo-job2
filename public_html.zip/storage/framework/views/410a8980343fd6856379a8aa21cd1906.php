<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('imgs/logo.png')); ?>">
        <title>Energo job</title>
    </head>
    <body>
        <div class="header">
            <a href="<?php echo e(route('profiles.index')); ?>" class="header_logo">
                <img src="<?php echo e(asset('/imgs/logo.png')); ?>" class="logo_img">
            </a>
            <button class="auth-button"><a href="<?php echo e(route('profiles.index')); ?>">На главную</a></button>
        </div>

        <?php echo e($slot); ?>

    </body>
</html>
<?php /**PATH C:\xampp\htdocs\public_html\resources\views/components/layouts/app.blade.php ENDPATH**/ ?>