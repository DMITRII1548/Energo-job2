<div>
    <h1>Hello, <?php echo e($user->name); ?></h1>
    <button class="btn btn-danger" wire:click="logout">Log out</button>
</div>
<?php /**PATH C:\xampp\htdocs\public_html\resources\views/livewire/auth/profile.blade.php ENDPATH**/ ?>