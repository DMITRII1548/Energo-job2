<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('imgs/logo.png')); ?>">
    <title>Energo job</title>
</head>
<body> 
    <?php echo e($slot); ?>

</body>
</html><?php /**PATH W:\domains\livewire-hh\resources\views/layouts/auth.blade.php ENDPATH**/ ?>