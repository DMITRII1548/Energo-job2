<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('imgs/logo.png')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/auth/verify-email.css']); ?>
    <title>Energo job</title>
</head>
<body>
    <div class="card">
        <form class="promo" action="<?php echo e(route('verification.send')); ?>" method="post">
            <h1>Подтвердите почту</h1> 
            <h3>Мы отправили письмо вам на почту</h3>
            <h6>Не прошило письмо?</h6><br>

            <?php echo csrf_field(); ?>
            <button type="submit">Отправить ещё раз</button>
        </form>
    </div>
</body>
</html><?php /**PATH W:\domains\livewire-hh\resources\views/auth/verify-email.blade.php ENDPATH**/ ?>