<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH W:\domains\livewire-hh\resources\views/vendor/mail/text/button.blade.php ENDPATH**/ ?>