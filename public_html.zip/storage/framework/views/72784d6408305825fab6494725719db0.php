<div>
    <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">Пользователи</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item active"></li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <!-- Small boxes (Stat box) -->
          <div class="row">
            <div class="col-12">

                <div class="card-body table-responsive p-0" height="1000px">
                <table class="table table-head-fixed">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>ФИО</th>
                            <th>Номер телефона</th>
                            <th>email</th>
                            <th>Аватар</th>
                            <th>Опыт работы</th>
                            <th>Портфолио</th>
                            <th>Профессии</th>
                            <th>Навыки</th>
                            <th>Статус</th>
                            <th>Удалать</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($user->id); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->phonenumber); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <!--[if BLOCK]><![endif]--><?php if(isset($user->profile->avatarUrl)): ?>
                                    <td><img src="<?php echo e($user->profile->avatarUrl); ?>" style="width: 100px;"></td>
                                    <td><?php echo e($user->profile->expirience); ?></td>
                                    <td><?php echo e($user->profile->portfolio); ?></td>

                                    <td>
                                        <ul>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $user->profile->professions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profession): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($profession->title); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        <ul>
                                    </td>

                                    <td>
                                        <ul>
                                            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $user->profile->skills; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($skill->title); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                                        <ul>
                                    </td>

                                    <td>
                                        <!--[if BLOCK]><![endif]--><?php if(!$user->profile->is_published): ?>
                                            <button wire:click="changeStatus(<?php echo e($user->id); ?>)" class="btn btn-primary">Опубликовать</button>
                                        <?php else: ?>
                                            <button wire:click="changeStatus(<?php echo e($user->id); ?>)" class="btn btn-danger">Снять с публикации</button>
                                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                    </td>
                                <?php else: ?> 
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                                <td><button
                                    wire:click="destroy(<?php echo e($user->id); ?>)"
                                    wire:confirm="Подтвердите действие"
                                    class="btn btn-danger">Удалить</button></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>
                </div>
                <?php echo e($users->links()); ?>

                </div>

                </div>
          </div>
          <!-- /.row -->

          <!-- /.row (main row) -->
        </div><!-- /.container-fluid -->
      </section>
      <!-- /.content -->
</div>
<?php /**PATH /home/a0984209/domains/a0984209.xsph.ru/public_html/resources/views/livewire/admin/user/index.blade.php ENDPATH**/ ?>