<div>
        <?php
        $__assetKey = '3967574561-0';

        ob_start();
    ?>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/auth/register.css']); ?>
        <?php
        $__output = ob_get_clean();

        // If the asset has already been loaded anywhere during this request, skip it...
        if (in_array($__assetKey, \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$alreadyRunAssetKeys)) {
            // Skip it...
        } else {
            \Livewire\Features\SupportScriptsAndAssets\SupportScriptsAndAssets::$alreadyRunAssetKeys[] = $__assetKey;
            \Livewire\store($this)->push('assets', $__output, $__assetKey);
        }
    ?>
<div class="bg">
    <div id="baner">
        <div class="aba">
            <div>
                <a>Если у вас есть профиль, то войдите</a>
            </div>  
            <div class="btn7">
                <button wire:click="login" id="btn8">Войти</button>
            </div>
            <div>
                <div class="btn11">
                    <a href="<?php echo e(route('profiles.index')); ?>" id="btn12">На главную</a>
                </div>
            </div>
        </div>
    </div>
    <div id="baner2" class="none">
        <div class="aba">
            <div>
                <a>Если у вас есть профиль, то войдите</a>
            </div>  
            <div class="btn9">
                <button id="btn10">Зарегистривоваться</button>
            </div>
            <div>
                <div class="btn11">
                    <a href="./main.html" id="btn12">На главную</a>
                </div>
            </div>
        </div>
    </div>
        <div class="log">
            <div class="log1">
                <h1>Войти</h1>
                <div class="inputBox">
                    <input type="text" required="required" class="qwerty">
                    <span class="qwe">Почта</span>
                </div>
                <div class="inputBox">
                    <input type="text" required="required">
                    <span>Пароль</span>
                </div>
                <div class="btn">
                    <button class="btn1">Войти</button>
                </div>
            </div>
        </div>
        <form class="reg" wire:submit="register">
            <div class="reg1">
                <h1>Регистрация</h1>
                <div class="inputBox">
                    <input type="text" required="required" wire:model="form.name">
                    <span>Имя, Фамилия</span>
                </div>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                <div class="inputBox">
                    <input type="email" required="required" wire:model="form.email">
                    <span>Почта</span>
                </div>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                <div class="inputBox">
                    <input type="tel" required="required" wire:model="form.phonenumber">
                    <span>Телефон</span>
                </div>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.phonenumber'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                <div class="inputBox">
                    <input type="password" required="required" wire:model="form.password">
                    <span>Пароль</span>
                </div>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                <div class="inputBox">
                    <input type="password" required="required" wire:model="form.password_confirmation">
                    <span>Подтвердить</span>
                </div>
                <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <p class="danger"><?php echo e($message); ?></p>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
                <div class="btn2">
                    <button class="btn3" type="submit">Зарегистрироваться</button>
                </div>
            </div>
        </form>
    </div>
</div><?php /**PATH C:\xampp\htdocs\public_html\resources\views/livewire/auth/register.blade.php ENDPATH**/ ?>