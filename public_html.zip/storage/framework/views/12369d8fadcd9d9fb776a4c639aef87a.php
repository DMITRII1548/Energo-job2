<?php echo e($slot); ?>

<?php /**PATH W:\domains\livewire-hh\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>