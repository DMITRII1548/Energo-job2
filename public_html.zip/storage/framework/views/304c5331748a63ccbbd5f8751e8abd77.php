<div>
    <form class="form-group" wire:submit="forgot" class="form-control">
        <input type="email" wire:model="form.email" placeholder="Email" class="form-control">
        <!--[if BLOCK]><![endif]--><?php $__errorArgs = ['form.email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-danger"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?><!--[if ENDBLOCK]><![endif]-->
        <!--[if BLOCK]><![endif]--><?php if($status): ?>
            <div><?php echo e($status); ?></div>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        <button type="submit" class="btn btn-success">Сбросить пароль</button>
    </form>
</div>
<?php /**PATH C:\xampp\htdocs\livewire-hh\resources\views/livewire/auth/forgot-password.blade.php ENDPATH**/ ?>