<?php echo e($slot); ?>

<?php /**PATH /home/a0984209/domains/a0984209.xsph.ru/public_html/resources/views/vendor/mail/text/footer.blade.php ENDPATH**/ ?>