<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="icon" type="image/x-icon" href="<?php echo e(asset('imgs/logo.png')); ?>">
        <title>Energo job</title>
    </head>
    <body>
        <div class="header">
            <a href="<?php echo e(route('profiles.index')); ?>" class="header_logo">
                <img src="<?php echo e(asset('/imgs/logo.png')); ?>" class="logo_img">
            </a>
            <?php if(auth()->user()): ?>
            <div>
                <h3><?php echo e(auth()->user()->name); ?></h3>
            </div>
            <div style="display: flex; align-items:center; gap: 30px">
                <?php if(auth()->user()->hasRole('admin')): ?>
                    <div class="header_link">
                        <a href="<?php echo e(route('admin.users.index')); ?>" class="header_txt">Админ панель</a>
                    </div>
                <?php endif; ?>
                <div class="header_link">
                    <a href="<?php echo e(route('profiles.update_or_create')); ?>" class="header_txt">Профиль</a>
                </div>
                <form action="<?php echo e(route('auth.logout')); ?>" method="post" class="header_link">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="header_txt">Выйти</button>
                </form>
            </div>

            <?php else: ?>
            <div class="header_link">
                <a href="<?php echo e(route('auth.login')); ?>" class="header_txt">Войти</a>
            </div>
            <?php endif; ?>
        </div>

        <?php echo e($slot); ?>

    </body>
</html>
<?php /**PATH W:\domains\livewire-hh\resources\views/layouts/main.blade.php ENDPATH**/ ?>