<?php $__env->startSection('content'); ?> 
<div class="promo">
        <div class="pr">
            <h1>Как работает наш сайт?</h1>
        </div>
        <div class="cards">
            <div class="row1">
                <img src="<?php echo e(asset('imgs/welcome/numbers/1.png')); ?>" alt="" class="number">
                <div class="reg1">
                    <p class="reg_site">
                        Зарегистрируйтесь на сайте 
                    </p>
                    <p class="fast">
                        Это быстро и бесплатно
                    </p>  
                </div>  
                <div class="card_img">
                    <img src="<?php echo e(asset('imgs/welcome/cards/1.png')); ?>" alt="" style="width: 200px;height: 200px;">
                </div>          
            </div>

            <div class="row1">
                <img src="<?php echo e(asset('imgs/welcome/numbers/2.png')); ?>" alt="" class="number">
                <div class="reg1">
                    <p class="reg_site">
                        Выберите нужную услугу
                    </p>
                    <p class="fast">
                        Выберите услугу на любой вкус
                    </p>  
                </div>  
                <div class="card_img">
                    <img src="<?php echo e(asset('imgs/welcome/cards/2.png')); ?>" alt="" style="width: 200px;height: 200px;">
                </div>          
            </div>

            <div class="row1">
                <img src="<?php echo e(asset('imgs/welcome/numbers/3.png')); ?>" alt="" class="number">
                <div class="reg1">
                    <p class="reg_site">
                        Найдите подходящего исполнителя 
                    </p>
                    <p class="fast">
                        У нас много анкет 
                    </p>  
                </div>  
                <div class="card_img">
                    <img src="<?php echo e(asset('imgs/welcome/cards/3.png')); ?>" alt="" style="width: 200px;height: 200px;">
                </div>          
            </div>

        </div>
        
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/a0928475/domains/a0928475.xsph.ru/resources/views/welcome.blade.php ENDPATH**/ ?>