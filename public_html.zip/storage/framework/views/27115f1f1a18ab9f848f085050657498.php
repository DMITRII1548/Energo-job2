<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/a0928475/domains/a0928475.xsph.ru/resources/views/vendor/mail/text/button.blade.php ENDPATH**/ ?>