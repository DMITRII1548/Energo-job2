<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Energo-job</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/welcome.css']); ?>
</head>
<body>
    <header>
        <div class="container">
            <div class="header_flex">
                <a href="/"><img src="<?php echo e(asset ('imgs/welcome/logo.jpg')); ?>" alt=""></a>
                <nav>
                    <a href="<?php echo e(route('profiles.index')); ?>">Фриланс</a>
                    <a href="<?php echo e(route('auth.login')); ?>">Войти</a>
                    <a href="<?php echo e(route('auth.register')); ?>">Регистрация</a>
                </nav>
            </div>
        </div>
    </header>
    <main>
        <section>
            <div class="container">
                <div class="info_message">
                    <div class="text">
                        <h1>Выбирай работу по вкусу и желанию</h1>
                    </div>
                </div>
                <div class="info_message2">
                    <div class="text">
                        <h1>У нас есть курсы для вашего продвижения как для студентов так и для работадателя.</h1>
                    </div>
                </div>
                <div class="more">
                    <a href="<?php echo e(route('profiles.index')); ?>"><button>Подробнее...</button></a>
                </div>
            </div>
        </section>
    </main>
</body>
</html><?php /**PATH C:\xampp\htdocs\public_html\resources\views/welcome.blade.php ENDPATH**/ ?>