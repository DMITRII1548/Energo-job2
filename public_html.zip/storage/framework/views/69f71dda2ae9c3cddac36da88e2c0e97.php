<div>
    <div class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1 class="m-0">Профессии</h1>
            </div><!-- /.col -->
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item active"></li>
              </ol>
            </div><!-- /.col -->
          </div><!-- /.row -->
        </div><!-- /.container-fluid -->
    </div>
      <!-- /.content-header -->

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <!-- Small boxes (Stat box) -->
          <div class="row">
            
            <div class="col-12">
            <div class="card">
                    <div class="card-header">
                        <a wire:click="add" class="btn btn-success">Добавить</a>
                    </div>
                </div>
                <div class="card-body table-responsive p-0" height="1000px">
                <table class="table table-head-fixed">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Наименование</th>
                            <th>Изменить</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $professions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profession): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($profession->id); ?></td>
                                <td><?php echo e($profession->title); ?></td>
                                <td><a wire:click="edit(<?php echo e($profession->id); ?>)" href="#" class="btn btn-primary">Изменить</a></td>
                                <td><a wire:click="destroy(<?php echo e($profession->id); ?>)" href="#" class="btn btn-danger">Удалить</a></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                    </tbody>
                </table>

                </div>
          </div>
          <!-- /.row -->

          <!-- /.row (main row) -->
        </div><!-- /.container-fluid -->
      </section>
      <!-- /.content -->
</div>
<?php /**PATH /home/a0984209/domains/a0984209.xsph.ru/public_html/resources/views/livewire/admin/profession/index.blade.php ENDPATH**/ ?>