<?php echo e($slot); ?>

<?php /**PATH W:\domains\livewire-hh\resources\views/vendor/mail/text/subcopy.blade.php ENDPATH**/ ?>