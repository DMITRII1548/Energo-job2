<div>
    <h1>Hello, {{ $user->name }}</h1>
    <button class="btn btn-danger" wire:click="logout">Log out</button>
</div>
